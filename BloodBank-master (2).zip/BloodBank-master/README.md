
# BloodBank

**Why we need BloodBank** 

Today, blood banks collect blood and separate it into its various components so they can be used most effectively according to the needs of the patient. Blood is the vital connection to having a healthy body, and according to the American Red Cross, nearly 5 million people receive blood transfusions each year.



## Screenshots

![App Screenshot_0](https://github.com/sugukung/BloodBank/blob/master/BloodBankScreenShoots/0.jpeg)

  ![App Screenshot_1](https://github.com/sugukung/BloodBank/blob/master/BloodBankScreenShoots/1.jpeg)

  ![App Screenshot_2](https://github.com/sugukung/BloodBank/blob/master/BloodBankScreenShoots/2.jpeg)

  ![App Screenshot_3](https://github.com/sugukung/BloodBank/blob/master/BloodBankScreenShoots/3.jpeg)

  ![App Screenshot_4](https://github.com/sugukung/BloodBank/blob/master/BloodBankScreenShoots/4.jpeg)

  ![App Screenshot_5](https://github.com/sugukung/BloodBank/blob/master/BloodBankScreenShoots/5.jpeg)

  ![App Screenshot_6](https://github.com/sugukung/BloodBank/blob/master/BloodBankScreenShoots/6.jpeg)

  ![App Screenshot_7](https://github.com/sugukung/BloodBank/blob/master/BloodBankScreenShoots/7.jpeg)


  
## Support
If you've any questions regarding this Project, please contact us at dev001.sahil@gmail.com

## Credits

This project was initiated by **Sahil kumar**. You can contribute to this project by submitting issues or/and by forking this repo and sending a pull request.
